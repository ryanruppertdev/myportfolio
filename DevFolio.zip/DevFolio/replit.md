# Overview

This is a modern, responsive React portfolio application built with TypeScript, featuring a full-stack architecture with Express.js backend and PostgreSQL database integration. The portfolio showcases a professional developer's work with animated components, dark/light theme support, and interactive features including project showcases, skills visualization, and contact forms.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture

The frontend is built using React with TypeScript and follows a modern component-based architecture:

- **Component Structure**: Organized into logical sections (Hero, About, Projects, Contact, Navbar) with a main Portfolio component orchestrating the layout
- **UI Framework**: Utilizes shadcn/ui components built on Radix UI primitives for consistent, accessible design
- **Styling**: Tailwind CSS with custom CSS variables for theming, supporting both light and dark modes
- **Animations**: Framer Motion for smooth scroll animations, hover effects, and page transitions
- **State Management**: React hooks for local state, React Query for server state management
- **Type Safety**: Full TypeScript implementation with strict type checking

## Backend Architecture

The backend follows a clean Express.js architecture:

- **Server Framework**: Express.js with TypeScript support
- **Routing**: Centralized route registration system with API prefix structure
- **Storage Interface**: Abstracted storage layer with in-memory implementation (extensible to database)
- **Development Setup**: Vite integration for hot module replacement and development server
- **Error Handling**: Centralized error handling middleware

## Data Storage

- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Schema Management**: Centralized schema definitions in shared directory
- **Migration System**: Drizzle Kit for database migrations and schema updates
- **Connection**: Neon Database serverless PostgreSQL integration
- **Validation**: Zod schemas for runtime type validation

## Theme and Design System

- **Design Tokens**: CSS custom properties for consistent theming
- **Component Library**: shadcn/ui for pre-built, customizable components
- **Responsive Design**: Mobile-first approach with Tailwind's responsive utilities
- **Typography**: Custom font loading (Inter, DM Sans, Fira Code, Geist Mono)
- **Color System**: Comprehensive color palette with semantic naming

## Build and Development

- **Build Tool**: Vite for fast development and optimized production builds
- **Package Management**: npm with lockfile for consistent dependencies
- **Development Server**: Hot reload with error overlay integration
- **Production Build**: Separate client and server builds with static asset optimization
- **TypeScript Configuration**: Shared configuration across client, server, and shared modules

# External Dependencies

## UI and Animation Libraries

- **Radix UI**: Comprehensive component primitives for accessibility and functionality
- **Framer Motion**: Advanced animation library for smooth interactions and transitions
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon sets (FontAwesome integration)

## Database and ORM

- **Neon Database**: Serverless PostgreSQL hosting platform
- **Drizzle ORM**: Type-safe database toolkit with excellent TypeScript integration
- **Drizzle Kit**: CLI tool for database migrations and schema management

## Development and Build Tools

- **Vite**: Modern build tool with fast HMR and optimized bundling
- **TypeScript**: Static type checking across the entire application
- **Tailwind CSS**: Utility-first CSS framework for rapid styling
- **PostCSS**: CSS processing with Autoprefixer support

## Form and Validation

- **React Hook Form**: Performant form library with minimal re-renders
- **Zod**: Runtime type validation and schema definition
- **Hookform Resolvers**: Integration between React Hook Form and Zod

## State Management and Data Fetching

- **TanStack React Query**: Server state management with caching and background updates
- **React Context**: Theme management and global state

## Replit Integration

- **Replit Vite Plugins**: Runtime error modal and cartographer for development experience
- **Replit Banner**: Development environment indicator